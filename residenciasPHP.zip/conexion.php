<?php
$nombreServer = 'DESKTOP-L4BS0N0\SQLEXPRESS';
$infoDeConexion = array("Database" => "Residencias", "UID"=>"docente","PWD"=>"1234");
$conexion = sqlsrv_connect($nombreServer, $infoDeConexion);
$sql = "";

    function validacion($conexion,$infoDeConexion){
        if ($conexion) {
          return true;
        } else {
          die('No se pudo conectar a la base de datos, revise las credenciales');
          return false;
        }
    }
    
    function consulta($conexion){
        global $sql; 
        $sql= "SELECT * FROM alumno";
        $stmt = sqlsrv_query($conexion, $sql);
        return $stmt;
    }
?>